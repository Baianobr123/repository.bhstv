# -*- coding: utf-8 -*-
import sys
import xbmcgui
import xbmcplugin
import urllib.request

# 1. Configurações de URLs e Imagens
URLS = {
    'canais': "https://gitlab.com/BHS_TV/bhs_tv/-/raw/main/CHANNELS.txt",
    'filmes': "https://gitlab.com/BHS_TV/bhs_tv/-/raw/main/MOVIES.txt",
    'series': "https://gitlab.com/BHS_TV/bhs_tv/-/raw/main/SERIES.txt"
}

IMG_SEARCH = "https://imgur.com/xeUbPyj.png"
IMG_TV     = "https://imgur.com/31vnSVm.png"
IMG_MOVIES = "https://imgur.com/1gWW9MP.png"
IMG_SERIES = "https://imgur.com/hsVp6Rr.png"
FANART     = "https://imgur.com/uuRf2gE.jpg"

HANDLE = int(sys.argv[1])
U_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

def get_data(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': U_AGENT})
        response = urllib.request.urlopen(req, timeout=15)
        return response.read().decode('utf-8', 'ignore')
    except: return ""

def add_dir(name, url, icon):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': icon, 'icon': icon, 'fanart': FANART})
    xbmcplugin.addDirectoryItem(HANDLE, url, li, True)

def main():
    # Pega os parametros da URL de forma ultra simples
    params = sys.argv[2][1:]
    
    if not params:
        # MENU PRINCIPAL
        add_dir('[COLOR yellow]🔍 BHS TV - PESQUISAR[/COLOR]', sys.argv[0] + '?mode=search', IMG_SEARCH)
        add_dir('📺 BHS TV - TV AO VIVO', sys.argv[0] + '?mode=list_cats&type=canais', IMG_TV)
        add_dir('🎬 BHS TV - FILMES', sys.argv[0] + '?mode=list_cats&type=filmes', IMG_MOVIES)
        add_dir('🍿 BHS TV - SÉRIES / ANIMES', sys.argv[0] + '?mode=list_cats&type=series', IMG_SERIES)

    elif 'mode=list_cats' in params:
        l_type = params.split('type=')[1].split('&')[0]
        data = get_data(URLS[l_type])
        cats = []
        for line in data.split('#EXTINF'):
            if 'group-title="' in line:
                gname = line.split('group-title="')[1].split('"')[0]
                if gname not in cats: cats.append(gname)
        
        cats.sort()
        icon_f = IMG_TV if l_type == 'canais' else (IMG_MOVIES if l_type == 'filmes' else IMG_SERIES)
        for c in cats:
            # Usamos um formato de URL que nao precisa de "quote" para nao dar erro
            url = sys.argv[0] + '?mode=list_items&type=' + l_type + '&cat=' + c.replace(' ', '%20')
            add_dir(c, url, icon_f)

    elif 'mode=list_items' in params:
        l_type = params.split('type=')[1].split('&')[0]
        # Pega a categoria tratando o espaço que colocamos acima
        target_cat = params.split('cat=')[1].split('&')[0].replace('%20', ' ')
        
        data = get_data(URLS[l_type])
        for chunk in data.split('#EXTINF')[1:]:
            if 'group-title="' + target_cat + '"' in chunk:
                name = chunk.split(',')[-1].split('\n')[0].strip()
                lines = chunk.split('\n')
                v_url = ""
                for l in lines:
                    if l.strip().startswith('http'):
                        v_url = l.strip()
                        break
                
                if v_url:
                    li = xbmcgui.ListItem(label=name)
                    logo = ""
                    if 'tvg-logo="' in chunk:
                        logo = chunk.split('tvg-logo="')[1].split('"')[0]
                    
                    default_img = IMG_TV if l_type == 'canais' else IMG_MOVIES
                    img = logo if logo else default_img
                    li.setArt({'thumb': img, 'icon': img, 'fanart': FANART})
                    
                    li.setInfo('video', {'title': name})
                    li.setProperty('IsPlayable', 'true')
                    
                    # URL para o player com User-Agent fixo
                    final_url = v_url + '|User-Agent=Mozilla/5.0'
                    
                    if l_type == 'canais':
                        li.setProperty('inputstream', 'inputstream.adaptive')
                        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
                    
                    xbmcplugin.addDirectoryItem(HANDLE, final_url, li, False)

    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    main()